-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 04 Juin 2015 à 11:51
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `qrcode`
--
CREATE DATABASE IF NOT EXISTS `qrcode` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `qrcode`;

-- --------------------------------------------------------

--
-- Structure de la table `card`
--

DROP TABLE IF EXISTS `card`;
CREATE TABLE IF NOT EXISTS `card` (
  `id_card` int(11) NOT NULL AUTO_INCREMENT,
  `prenom` varchar(255) COLLATE utf8_bin NOT NULL,
  `nom` varchar(255) COLLATE utf8_bin NOT NULL,
  `cin` varchar(8) COLLATE utf8_bin NOT NULL,
  `sexe` varchar(5) COLLATE utf8_bin NOT NULL,
  `date_naissance` date NOT NULL,
  `adress` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `statut` varchar(255) COLLATE utf8_bin NOT NULL,
  `photo` varchar(255) COLLATE utf8_bin NOT NULL,
  `inclusion` varchar(255) COLLATE utf8_bin NOT NULL,
  `card` varchar(255) COLLATE utf8_bin NOT NULL,
  `newsletter` varchar(255) COLLATE utf8_bin NOT NULL,
  `etat` int(11) NOT NULL,
  PRIMARY KEY (`id_card`),
  UNIQUE KEY `cin` (`cin`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Contenu de la table `card`
--

INSERT INTO `card` (`id_card`, `prenom`, `nom`, `cin`, `sexe`, `date_naissance`, `adress`, `email`, `statut`, `photo`, `inclusion`, `card`, `newsletter`, `etat`) VALUES
(1, 'Bacem', 'BEN ACHOUR', '09622305', 'homme', '1994-10-10', 'L12 Résidence El Ezz 2040 Rades', 'bacem.benachour@youthdecides.org', 'junior', 'images\\Resources\\09622305.png', 'Technologique', 'userCard\\09622305.png', 'non', 0),
(2, 'Alaa', 'Ksontini', '09611959', 'homme', '1992-01-07', 'L12 RÃ©sidence El Ezz 2040 Megrine', 'alaa.ksontini@esprit.tn', 'junior', '../view/images/Resources/photo/alaa.png', 'culturelle technologique ', 'userCard/09611959.pdf', 'non', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
